package day12;

public class Ex17_Child extends Ex17_Parent {
	Ex17_Child(){
		System.out.println("Child Instance Created");
	}
}
