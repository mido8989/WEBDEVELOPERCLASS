package day12;

public class Ex17_Parent {
	Ex17_Parent(){
		System.out.println("Parent Instance Created");
	}
}
